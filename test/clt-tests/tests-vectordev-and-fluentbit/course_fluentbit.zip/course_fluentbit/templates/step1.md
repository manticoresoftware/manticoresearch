## Introduction

Manticore allows you to index data collected with the Fluentbit agent.

To do this, you must have Fluentbit installed on your local machine.


## Indexing data with Fluentbit

Here is a simple example of how you can use FluentBit togenther with Manticore. The example demonstrates the indexing of the ``dpkg.log``, a standard log file of the Debian package manager:

`cat /var/log/dpkg.log`

And here is our Fluentbit configuration file:

`cat fluentbit.conf`

We start FluentBit in the daemon mode and with the ``INPUT`` ``inotify_watcher`` option disabled to avoid possible problems with the Docker environment which exist in some agent's versions and can lead to errors.

`fluent-bit -c fluentbit.conf`

Now let's wait a few seconds until Fluentbit finishes its work and make a data check:

`mysql -P9306 -h0`

`SHOW TABLES;`

`DESCRIBE testlog;`

`SELECT * FROM testlog LIMIT 3\G`

`exit;`

As we see, the data collected by FluentBit is succesfully indexed and stored in the Manticore ``testlog`` table.

