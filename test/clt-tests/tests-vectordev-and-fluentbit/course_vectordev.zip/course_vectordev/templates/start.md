####Manticoresearch - integration with Vector by Datadog
   This tutorial will explain about using Manticore together with Vector by Datadog
   
   *Note that if you install Manticore manually you'll need to install the 'manticore-extra' package to enable the functionality described in this course.*

   