## Introduction

Manticore allows you to index data collected with the Vector.dev agent.

To do this, you must have Vector.dev installed on your local machine.


## Indexing data with Vector by Datadog

Here is a simple example of how you can use Vector together with Manticore. The example demonstrates the indexing of the ``dpkg.log``, a standard log file of the Debian package manager:

`cat /var/log/dpkg.log`

Here is a Vector config in the ``toml`` format:

`cat vector.toml`

Note that we've added the ``transforms`` section to the config to rename the default ``timestamp`` field as it's a reserved word in Manticore.

We'll use a manticore table named ``testlog`` to store data received from each beat agent. 

Run the agent in background:

`nohup vector -c vector.toml 2>/dev/null &`

Now wait a few seconds for data to be collected and processed and then check the table's schema and content:

`mysql -P9306 -h0`

`SHOW TABLES;`

`DESCRIBE testlog;`

`SELECT * FROM testlog LIMIT 3\G`

`exit;`

As we see, the data collected by Vector is succesfully indexed and stored in the Manticore table.
